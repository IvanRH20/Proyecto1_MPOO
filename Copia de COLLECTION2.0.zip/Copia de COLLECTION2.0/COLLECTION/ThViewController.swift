//
//  ThViewController.swift
//  COLLECTION
//
//  Created by 2020-1 on 9/25/19.
//  Copyright © 2019 ioslabv. All rights reserved.
//

import UIKit

class ThViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func salir(_ sender: Any) {}
    
    @IBAction func atras(_ sender: Any) {
        dismiss (animated: true, completion: nil)
    }
}
