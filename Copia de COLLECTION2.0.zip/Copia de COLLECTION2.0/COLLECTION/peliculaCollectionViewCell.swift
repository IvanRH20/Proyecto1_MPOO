//
//  peliculaCollectionViewCell.swift
//  COLLECTION
//
//  Created by 2020-1 on 9/11/19.
//  Copyright © 2019 ioslabv. All rights reserved.
//

import UIKit

class peliculaCollectionViewCell: UICollectionViewCell {
 
    
    @IBOutlet weak var POSTER: UIImageView!
    
    @IBOutlet weak var NOMBRE: UILabel!
    
    @IBOutlet weak var Horario: UILabel!
    
}
