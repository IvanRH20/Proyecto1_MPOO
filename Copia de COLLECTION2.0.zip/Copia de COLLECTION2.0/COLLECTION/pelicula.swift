//
//  pelicula.swift
//  COLLECTION
//
//  Created by 2020-1 on 9/11/19.
//  Copyright © 2019 ioslabv. All rights reserved.
//

import UIKit

struct pelicula{
    var poster: String
    var titulo: String
    var horario: String
    
}
